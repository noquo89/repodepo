The artwork in this folder is licensed under a Creative Commons Attribution-ShareAlike 4.0 Unported License

Some artwork in this folder is attributed to Estuary by phil65 (Team Kodi)
https://github.com/phil65/skin.estuary

You can find the license details here: <http://creativecommons.org/licenses/by-sa/4.0/>